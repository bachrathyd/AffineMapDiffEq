function Z=historyInterp(t,par)
Z=par.h(t).';
end